import './style.css'

//import './topics/01-basic-types'
//import './topics/02-object-interface'
//import './topics/03-function'
//import './topics/04-homework-types'
//import './topics/05-basic-destructuring'
import './topics/06-function-destructuring'

const app = document.querySelector<HTMLDivElement>('#app')!;

app.innerHTML = `Hola mundo!`;

console.log('Hola mundo!');


